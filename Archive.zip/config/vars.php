<?php
return [
    'adminFolder' => 'FrontEnd', // for template forlder name
    'adminURL' => '', // for path of admin
];
