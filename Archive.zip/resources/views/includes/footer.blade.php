<footer class="footer">

    <div class="container-fluid clearfix">

      <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2020

        <a href="http://www.quartzsolution.com" target="_blank">Quartz Solution</a>. All rights reserved.</span>



    </div>

  </footer>
