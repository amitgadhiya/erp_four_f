@extends('layouts.default')
@section('title')
    In-Ward Edit
@endsection
@section('content')
@endsection