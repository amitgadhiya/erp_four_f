<?php $__env->startSection('title'); ?>
    Income List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center">
        <h4>Income Records</h4>
        <a href="<?php echo e(route('income.add')); ?>" class="btn btn-primary">+ Add Income</a>
    </div>
    <table class="table table-bordered table-striped mt-3">
        <thead class="table-dark">
            <tr>
                <th>Income Date</th>
                <th>Source</th>
                <th>Type</th>
                <th>Total Amount (Rs)</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
            <!-- Example Row -->
            <tr>
                <td>2024-11-25</td>
                <td>XYZ Traders</td>
                <td>Sales</td>
                <td>₹50,000</td>
                <td>Payment for services</td>
            </tr>
            <!-- Add more rows dynamically -->
        </tbody>
    </table>
</div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/income/list.blade.php ENDPATH**/ ?>