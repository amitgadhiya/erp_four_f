<?php $__env->startSection('title'); ?>
    Purchase List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center">
        <h4>Purchase Records</h4>
        <a href="<?php echo e(route('purchase.add')); ?>" class="btn btn-primary">+ Add Purchase</a>
    </div>
    <table class="table table-bordered table-striped mt-3">
        <thead class="table-dark">
            <tr>
                <th>Purchase Date</th>
                <th>Purchase Order No</th>
                <th>Supplier Name</th>
                <th>Material</th>
                <th>Quantity</th>
                <th>Unit</th>
                <th>Total Cost</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
            <!-- Example Row -->
            <tr>
                <td>2024-11-25</td>
                <td>PO12345</td>
                <td>ABC Supplies</td>
                <td>Steel Plates</td>
                <td>300</td>
                <td>Kg</td>
                <td>10,000</td>
                <td>Delivered on time</td>
            </tr>
            <!-- Add more rows dynamically -->
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/purchase/list.blade.php ENDPATH**/ ?>