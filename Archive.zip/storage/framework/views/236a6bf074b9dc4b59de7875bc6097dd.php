<?php $__env->startSection('title'); ?>
    List User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex justify-content-end">
        <a href="<?php echo e(route('user.add')); ?>" class="btn btn-primary">Add User</a>
    </div>
</div>
<div class="table-responsive mt-3">
<table id="userTable" class="display">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $users = [
                (object) [
                    'id' => 1,
                    'name' => 'User 1',
                    'email' => 'user1@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 2,
                    'name' => 'User 2',
                    'email' => 'user2@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 3,
                    'name' => 'User 3',
                    'email' => 'user3@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 4,
                    'name' => 'User 4',
                    'email' => 'user4@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 5,
                    'name' => 'User 5',
                    'email' => 'user5@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 6,
                    'name' => 'User 6',
                    'email' => 'user6@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 7,
                    'name' => 'User 7',
                    'email' => 'user7@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 8,
                    'name' => 'User 8',
                    'email' => 'user8@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 9,
                    'name' => 'User 9',
                    'email' => 'user9@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 10,
                    'name' => 'User 10',
                    'email' => 'user10@example.com',
                    'role' => 'user',
                ],
                (object) [
                    'id' => 11,
                    'name' => 'Admin User',
                    'email' => 'admin@example.com',
                    'role' => 'admin',
                ],
            ];
        ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->role); ?></td>
                <td>
                    <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-primary">Edit</a>
                    <form action="<?php echo e(route('user.delete', $user->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#userTable').DataTable({
            // You can customize the DataTable options here
            responsive: true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/user/list.blade.php ENDPATH**/ ?>