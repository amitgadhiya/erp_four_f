<?php $__env->startSection('title'); ?>
     PO List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="table-responsive mt-3">
            <table id="poTable" class="display">
                <thead>
                    <tr>
                        <th>Sr.</th>
                        <th>PO no</th>
                        <th>Vender</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $pos = [
                            (object) [
                                'id' => 1,
                                'po_no' => 'PO01',
                                'vender' => 'Vender 1',
                                'date' => '2024-10-02',
                                'status' => 'received',
                            ],
                            (object) [
                                'id' => 2,
                                'po_no' => 'PO002',
                                'vender' => 'Vender 2',
                                'date' => '2024-10-02',
                                'status' => 'received',
                            ],
                            (object) [
                                'id' => 3,
                                'po_no' => 'PO003',
                                'vender' => 'Vender 3',
                                'date' => '2024-10-03',
                                'status' => 'Pending',
                            ],
                            (object) [
                                'id' => 4,
                                'po_no' => 'PO004',
                                'vender' => 'Vender 4',
                                'date' => '2024-10-04',
                                'status' => 'received',
                            ],
                            (object) [
                                'id' => 5,
                                'po_no' => 'PO005',
                                'vender' => 'Vender 5',
                                'date' => '2024-10-05',
                                'status' => 'Ordered',
                            ],
                            // Add more clients as needed
                        ];
                    ?>
            
                    <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($po->id); ?></td>
                        <td><?php echo e($po->po_no); ?></td>
                        <td><?php echo e($po->vender); ?></td>
                        <td><?php echo e($po->date); ?></td>
                        
                        <td><?php echo e($po->status); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-link pr-3" type="button" id="dropdownMenuButton-<?php echo e($po->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-<?php echo e($po->id); ?>">
                                    
                                    
                                    <li><a class="dropdown-item" href="<?php echo e(route('po.edit', $po->id)); ?>">Edit PO</a></li>

                                    <li><a class="dropdown-item" href="<?php echo e(route('po_item.list', $po->id)); ?>">Manage PO</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('po.view', $po->id)); ?>">View PO</a></li>
                                    
                                </ul>
                            </div>
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#poTable').DataTable({
            // You can customize the DataTable options here
            responsive: true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/po/list.blade.php ENDPATH**/ ?>