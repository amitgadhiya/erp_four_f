<?php $__env->startSection('title'); ?>
    Issue Project List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<table class="table table-striped table-bordered">
    <thead class="thead-dark">
        <tr>
            <th>Sr. No.</th>
            <th>Client Name</th>
            <th>Project No.</th>
            <th>Total Elements</th>
            <th>Issued Elements</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <!-- Example Rows -->
        <tr>
            <td>1</td>
            <td>ABC Pvt Ltd</td>
            <td>PRJ001</td>
            <td>100</td>
            <td>50</td>
            <td>
                <a href="<?php echo e(route('issue-elements.list')); ?>" class="btn btn-primary btn-sm">View</a>
            </td>
        </tr>
        <tr>
            <td>2</td>
            <td>XYZ Enterprises</td>
            <td>PRJ002</td>
            <td>200</td>
            <td>150</td>
            <td>
                <a href="<?php echo e(route('issue-elements.list')); ?>" class="btn btn-primary btn-sm">View</a>
            </td>
        </tr>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/issue/list.blade.php ENDPATH**/ ?>