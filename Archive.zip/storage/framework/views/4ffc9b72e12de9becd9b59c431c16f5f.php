<?php $__env->startSection('title'); ?>
    Element List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <style>
        .select2-container {
            width: 100% !important;
        }
    </style>
    <div class="row">
        <div class="col-lg-12 text-end">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#uploadModal">
                Upload Excel
            </button>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-4">
            <table class="table">
                <tr>
                    <td>Project Name : </td>
                    <td>Some name of prject</td>
                </tr>
                <tr>
                    <td>Project Number : </td>
                    <td>PJ005</td>
                </tr>
                <tr>
                    <td>Client Name : </td>
                    <td>Some Client Name</td>
                </tr>
                <tr>
                    <td>Project Start Date : </td>
                    <td>01-10-2024</td>
                </tr>
                <tr>
                    <td>Project Tartget Date : </td>
                    <td>30-10-2014</td>
                </tr>
                <tr>
                    <td>Project Status : </td>
                    <td>Production</td>
                </tr>
            </table>
        </div>
        <div class="col-lg-8">
            <form action="" method="POST">
                <div class="row">
                    <div class="col-lg-6">
                        <!-- Element Number -->
                        <div class="form-group">
                            <label for="elementNumber">Element Number</label>
                            <input type="text" class="form-control" id="elementNumber" name="elementNumber"
                                placeholder="Enter element number" required>
                        </div>

                        <!-- Element Name -->
                        <div class="form-group">
                            <label for="elementName">Element Name</label>
                            <input type="text" class="form-control" id="elementName" name="elementName"
                                placeholder="Enter element name" required>
                        </div>

                        <!-- Category -->
                        <div class="form-group">
                            <label for="category">Category</label>
                            <input type="text" class="form-control" id="category" name="category"
                                placeholder="Enter category" required>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <!-- Quantity -->
                        <div class="form-group">
                            <label for="quantity">Quantity</label>
                            <input type="number" class="form-control" id="quantity" name="quantity"
                                placeholder="Enter quantity" required>
                        </div>

                        <!-- Production Status (Select Dropdown) -->
                        <div class="form-group">
                            <label for="productionStatus">Production Status</label>
                            <select class="form-control" id="productionStatus" name="productionStatus" required>
                                <option value="">Select production status</option>
                                <option value="In Production">In Production</option>
                                <option value="Completed">Completed</option>
                                <option value="Pending">Pending</option>
                            </select>
                        </div>

                        <!-- Order Status (Select Dropdown) -->
                        <div class="form-group">
                            <label for="orderStatus">Order Status</label>
                            <select class="form-control" id="orderStatus" name="orderStatus" required>
                                <option value="">Select order status</option>
                                <option value="Ordered">Ordered</option>
                                <option value="Shipped">Shipped</option>
                                <option value="Delivered">Delivered</option>
                            </select>
                        </div>
                    </div>
                </div>




                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="table-responsive mt-3">
                <table id="elementTable" class="display">
                    <thead>
                        <tr>
                            <th>Sr.</th>
                            <th>Element no</th>
                            <th>Element Name</th>
                            <th>Element Type</th>
                            <th>Qty</th>
                            <th>Production Status</th>
                            <th>Ordered Status</th>
                            <th>Actions</th>
                        </tr>
                        <tr>
                            <!-- Dropdown filters for each column -->
                            <th>

                            </th>
                            <th>
                                <select class="column-filter" multiple="multiple">
                                    <option value="">All</option>
                                </select>
                            </th>
                            <th>
                                <select class="column-filter" multiple="multiple">
                                    <option value="">All</option>
                                </select>
                            </th>
                            <th>
                                <select class="column-filter" multiple="multiple">
                                    <option value="">All</option>
                                </select>
                            </th>
                            <th>
                                <select class="column-filter" multiple="multiple">
                                    <option value="">All</option>
                                </select>
                            </th>
                            <th>
                                <select class="column-filter" multiple="multiple">
                                    <option value="">All</option>
                                </select>
                            </th>
                            <th>
                                <select class="column-filter" multiple="multiple">
                                    <option value="">All</option>
                                </select>
                            </th>
                            <th></th> <!-- No filter for Actions column -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $elements = [
                                (object) [
                                    'id' => 1,
                                    'element_no' => 'EL001',
                                    'element' => 'name',
                                    'catg' => 'Hydraulic',
                                    'qty' => '1',
                                    'status_pro' => 'Started',
                                    'status_order' => 'pending',
                                ],
                                (object) [
                                    'id' => 2,
                                    'element_no' => 'EL002',
                                    'element' => 'name',
                                    'catg' => 'Hydraulic',
                                    'qty' => '1',
                                    'status_pro' => 'Cutting',
                                    'status_order' => 'revived',
                                ],
                                (object) [
                                    'id' => 3,
                                    'element_no' => 'EL003',
                                    'element' => 'name',
                                    'catg' => 'Raw Material',
                                    'qty' => '2',
                                    'status_pro' => 'Hardening',
                                    'status_order' => 'not ordered',
                                ],
                                (object) [
                                    'id' => 4,
                                    'element_no' => 'EL004',
                                    'element' => 'name',
                                    'catg' => 'Raw Material',
                                    'qty' => '1',
                                    'status_pro' => 'Rough Grinding',
                                    'status_order' => 'revived',
                                ],
                                (object) [
                                    'id' => 5,
                                    'element_no' => 'EL005',
                                    'element' => 'name',
                                    'catg' => 'Manufacturing',
                                    'qty' => '1',
                                    'status_pro' => 'Completed',
                                    'status_order' => 'revived',
                                ],
                                // Add more clients as needed
                            ];
                        ?>

                        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($element->id); ?></td>
                                <td><?php echo e($element->element_no); ?></td>
                                <td><?php echo e($element->element); ?></td>
                                <td><?php echo e($element->catg); ?></td>
                                <td><?php echo e($element->qty); ?></td>
                                <td><?php echo e($element->status_pro); ?></td>
                                <td><?php echo e($element->status_order); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-link pr-3" type="button"
                                            id="dropdownMenuButton-<?php echo e($element->id); ?>" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-<?php echo e($element->id); ?>">
                                            <li><a class="dropdown-item" href="#">edit Elements</a>
                                            </li>

                                            <li><a class="dropdown-item" href="#">Delete Element</a>
                                            </li>

                                        </ul>
                                    </div>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
    <!-- Modal Structure -->
<div class="modal fade" id="uploadModal" tabindex="-1" aria-labelledby="uploadModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="uploadModalLabel">Upload Excel File</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Form inside the modal -->
                <form id="uploadForm">
                    <div class="mb-3">
                        <label for="excelFile" class="form-label">Select Excel File</label>
                        <input type="file" class="form-control" id="excelFile" name="excelFile" accept=".xls, .xlsx">
                    </div>
                    <div class="mb-3">
                        <label for="excelFile" class="form-label">Type of elements</label>
                        <select class="form-control" id="elementType" name="elementType" required>
                            <option value="" disabled selected>Select type</option>
                            <option value="type1">Manufacturing element</option>
                            <option value="type2">Hydraulic element </option>
                            <option value="type3">Hardware</option>
                        </select>
                    </div>
                    
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" form="uploadForm">Upload</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#elementTable').DataTable({
                // You can customize the DataTable options here
                responsive: true,
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                initComplete: function() {
                    var api = this.api();

                    // For each column with a select element
                    api.columns().every(function() {
                        var column = this;
                        var select = $('select', this.header());

                        // Initialize Select2 for multi-select dropdowns
                        select.select2({
                            placeholder: 'Select options',
                            allowClear: true
                        });

                        // Populate the dropdown with unique column values
                        column.data().unique().sort().each(function(d, j) {
                            select.append('<option value="' + d + '">' + d +
                                '</option>')
                        });

                        // Handle multi-select filtering
                        select.on('change', function() {
                            var selected = $(this).val();

                            if (selected && selected.length > 0) {
                                // If options are selected, filter based on the selection
                                var regex = selected.map(function(val) {
                                    return '^' + $.fn.dataTable.util
                                        .escapeRegex(val) + '$';
                                }).join('|');
                                column.search(regex, true, false).draw();
                            } else {
                                // If no options are selected, clear the filter to show all rows
                                column.search('').draw();
                            }
                        });
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/element_in_project/list.blade.php ENDPATH**/ ?>