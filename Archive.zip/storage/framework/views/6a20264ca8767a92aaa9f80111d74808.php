<?php $__env->startSection('title'); ?>
    Element List 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 text-right">
        <a href="" class="btn btn-primary">Add Element</a>
    </div>
</div>
<div class="row">
    <div class="col-lg-4">
        <table class="table">
            <tr>
                <td>Project Name : </td>
                <td>Some name of prject</td>
            </tr>
            <tr>
                <td>Project Number : </td>
                <td>PJ005</td>
            </tr>
            <tr>
                <td>Client Name : </td>
                <td>Some Client Name</td>
            </tr>
            <tr>
                <td>Prject Start Date : </td>
                <td>01-10-2024</td>
            </tr>
            <tr>
                <td>Prject Tartget Date : </td>
                <td>30-10-2014</td>
            </tr>
            <tr>
                <td>Prject Status : </td>
                <td>Production</td>
            </tr>
        </table>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="table-responsive mt-3">
            <table id="elementTable" class="display">
                <thead>
                    <tr>
                        <th>Sr.</th>
                        <th>Element no</th>
                        <th>Element Name</th>
                        <th>Element Catg</th>
                        <th>Qty</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $elements = [
                            (object) [
                                'id' => 1,
                                'element_no' => 'EL001',
                                'element' => 'name',
                                'catg' => '1',
                                'qty' => '1',
                                'status' => 'Started',
                            ],
                            (object) [
                                'id' => 2,
                                'element_no' => 'EL002',
                                'element' => 'name',
                                'catg' => '2',
                                'qty' => '1',
                                'status' => 'Cutting',
                            ],
                            (object) [
                                'id' => 3,
                                'element_no' => 'EL003',
                                'element' => 'name',
                                'catg' => '3',
                                'qty' => '2',
                                'status' => 'Hardening',
                            ],
                            (object) [
                                'id' => 4,
                                'element_no' => 'EL004',
                                'element' => 'name',
                                'catg' => '3',
                                'qty' => '1',
                                'status' => 'Rough Grinding',
                            ],
                            (object) [
                                'id' => 5,
                                'element_no' => 'EL005',
                                'element' => 'name',
                                'catg' => '3',
                                'qty' => '1',
                                'status' => 'Completed',
                            ],
                            // Add more clients as needed
                        ];
                    ?>
            
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($element->id); ?></td>
                        <td><?php echo e($element->element_no); ?></td>
                        <td><?php echo e($element->element); ?></td>
                        <td><?php echo e($element->catg); ?></td>
                        <td><?php echo e($element->qty); ?></td>
                        <td><?php echo e($element->status); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-link pr-3" type="button" id="dropdownMenuButton-<?php echo e($element->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-<?php echo e($element->id); ?>">
                                    <li><a class="dropdown-item" href="<?php echo e(route('element.edit', $element->id)); ?>">Manage Elements</a></li>
                                    
                                    <li><a class="dropdown-item" href="<?php echo e(route('quotation.edit', $element->id)); ?>">Manage Status</a></li>
                                    
                                </ul>
                            </div>
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(document).ready(function() {
        $('#elementTable').DataTable({
            // You can customize the DataTable options here
            responsive: true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/element/list.blade.php ENDPATH**/ ?>