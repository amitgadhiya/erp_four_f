<?php $__env->startSection('title'); ?>
    Out-Ward List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="container mt-4 text-right">
            <a href="<?php echo e(route('out-ward.add')); ?>" class="btn btn-primary ">Add Outward</a>

        </div>
        <div class="container mt-4">
            <h4>Outward Records</h4>
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Date</th>
                        <th>Outward No</th>
                        <th>Customer Name</th>
                        <th>Material</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Delivered By</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Example Row -->
                    <tr>
                        <td>2024-11-25</td>
                        <td>OUT67890</td>
                        <td>XYZ Industries</td>
                        <td>Aluminum Sheets</td>
                        <td>200</td>
                        <td>Kg</td>
                        <td>Jane Smith</td>
                        <td>Delivered on schedule</td>
                    </tr>
                    <!-- Add more rows dynamically as needed -->
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/out-ward/list.blade.php ENDPATH**/ ?>