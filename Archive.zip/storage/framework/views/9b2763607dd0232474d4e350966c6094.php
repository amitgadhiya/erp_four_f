<?php $__env->startSection('title'); ?>
     PO List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 text-right">
        <a href="<?php echo e(route('po_item.add')); ?>" class="btn btn-primary">Add Item</a>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="table-responsive mt-3">
            <table id="itemTable" class="display">
                <thead>
                    <tr>
                        <th>Sr.</th>
                        <th>Item Name</th>
                        <th>Qty</th>
                        <th>Rate</th>
                        <th>Dis</th>
                        <th>Tax</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $items = [
                            (object) [
                                'id' => 1,
                                'po_item' => 'Item name 1',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            (object) [
                                'id' => 2,
                                'po_item' => 'Item name 2',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            (object) [
                                'id' => 3,
                                'po_item' => 'Item name 3',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            (object) [
                                'id' => 4,
                                'po_item' => 'Item name 4',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            (object) [
                                'id' => 5,
                                'po_item' => 'Item name 5',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            // Add more clients as needed
                        ];
                    ?>
            
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->po_item); ?></td>
                        <td><?php echo e($item->qty); ?></td>
                        <td><?php echo e($item->rate); ?></td>
                        
                        <td><?php echo e($item->discount); ?></td>
                        <td><?php echo e($item->tax); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-link pr-3" type="button" id="dropdownMenuButton-<?php echo e($item->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-<?php echo e($item->id); ?>">
                                    
                                    
                                    <li><a class="dropdown-item" href="<?php echo e(route('po_item.edit', $item->id)); ?>">Edit </a></li>

                                    <li><a class="dropdown-item" href="<?php echo e(route('po_item.delete', $item->id)); ?>">Delete</a></li>
                                    
                                </ul>
                            </div>
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#itemTable').DataTable({
            // You can customize the DataTable options here
            responsive: true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/po_item/list.blade.php ENDPATH**/ ?>