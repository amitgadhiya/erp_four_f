<!DOCTYPE html>

<html lang="en">

<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<body>

  <div class="container-scroller">

    <div class="container-fluid page-body-wrapper full-page-wrapper auth-page">

      <div class="content-wrapper d-flex align-items-center auth auth-bg-1 theme-one">

        <div class="row w-100">

          <div class="col-lg-4 mx-auto">

            <div class="auto-form-wrapper">

                <form action="/dashboard" method="get">
<?php echo csrf_field(); ?>
                    <div class="form-group" >

                        <h3 class="text-center"><?php echo e(config('app.name')); ?></h3>

<!--<img src="images/full logo.png" style="margin-left: 35px;">-->

                </div>

                <div class="form-group">

                  <label class="label">Username</label>

                  <div class="input-group">

                      <input type="text" name="email" class="form-control" placeholder="Username">

                    <div class="input-group-append">

                      <span class="input-group-text">

                        <i class="mdi mdi-check-circle-outline"></i>

                      </span>

                    </div>

                  </div>

                </div>

                <div class="form-group">

                  <label class="label">Password</label>

                  <div class="input-group">

                      <input type="password" name="password" class="form-control" placeholder="*********">

                    <div class="input-group-append">

                      <span class="input-group-text">

                        <i class="mdi mdi-check-circle-outline"></i>

                      </span>

                    </div>

                  </div>

                </div>

                <div class="form-group">

                    <input type="submit" class="btn btn-primary submit-btn btn-block" value="Login" name="submit">

                </div>

                <div class="form-group d-flex justify-content-between">





                </div>

                <div class="form-group d-flex justify-content-between">


                    <?php if($errors->any()): ?>
                    <div class='alert alert-danger'>
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    </div>
                    <?php endif; ?>
                    

                </div>





              </form>

            </div>



            <p class="footer-text text-center">copyright © <?php echo e(date('Y')); ?> . All rights reserved.</p>

          </div>

        </div>

      </div>

      <!-- content-wrapper ends -->

    </div>

    <!-- page-body-wrapper ends -->

  </div>
<?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>



</html>
<?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/login.blade.php ENDPATH**/ ?>