<?php $__env->startSection('title'); ?>
    List Row Item
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex justify-content-end">
        <a href="<?php echo e(route('row_item.add')); ?>" class="btn btn-primary">Add Raw Item</a>
    </div>
</div>
<div class="table-responsive mt-3">
    <table id="itemTable" class="display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Item Name</th>
                <th>Item Code</th>
                <th>Category</th>
                <th>Opening Stock</th>
                <th>Min Stock Alert</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $items = [
        (object) [
            'id' => 1,
            'name' => 'Item 1',
            'item_code' => 'ITM001',
            'category' => 'Consumable ',
            'opening_stock' => 50,
            'min_stock_alert' => 10
        ],
        (object) [
            'id' => 2,
            'name' => 'Item 2',
            'item_code' => 'ITM002',
            'category' => 'Raw material',
            'opening_stock' => 30,
            'min_stock_alert' => 5
        ]
    ];
            ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->item_code); ?></td>
                <td><?php echo e($item->category); ?></td>
                <td><?php echo e($item->opening_stock); ?></td>
                <td><?php echo e($item->min_stock_alert); ?></td>
                <td>
                    <a href="<?php echo e(route('row_item.edit', $item->id)); ?>" class="btn btn-primary">Edit</a>
                    <form action="<?php echo e(route('row_item.delete', $item->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#itemTable').DataTable({
            responsive: true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/row_item/list.blade.php ENDPATH**/ ?>