<?php $__env->startSection('title'); ?>
    Edit project
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-lg-12">
            <form action="<?php echo e(route('element_in_project.list')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="project_no">Project No:</label>
                            <input type="text" class="form-control" id="project_no" name="project_no" required>
                        </div>

                        <div class="form-group">
                            <label for="client_name">Client Name:</label>
                            <input type="text" class="form-control" id="client_name" name="client_name" required>
                        </div>

                        <div class="form-group">
                            <label for="project_end_date">Project End Date:</label>
                            <input type="date" class="form-control" id="project_end_date" name="project_end_date"
                                required>
                        </div>

                        <div class="form-group">
                            <label for="project_name">Project Name:</label>
                            <input type="text" class="form-control" id="project_name" name="project_name" required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-lg-3">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/project/edit.blade.php ENDPATH**/ ?>