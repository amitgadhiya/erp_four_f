<?php $__env->startSection('title'); ?>
    In-Ward List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h4>Stock Records</h4>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Material</th>
                <th>Stock ID</th>
                <th>Quantity Available</th>
                <th>Unit</th>
                <th>Last Inward Date</th>
                <th>Last Outward Date</th>
                <th>Status</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
            <!-- Example Row -->
            <tr>
                <td>Steel Rods</td>
                <td>STK001</td>
                <td>500</td>
                <td>Kg</td>
                <td>2024-11-20</td>
                <td>2024-11-24</td>
                <td>Available</td>
                <td>In good condition</td>
            </tr>
            <!-- Add more rows dynamically as needed -->
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/stock/list.blade.php ENDPATH**/ ?>