<?php $__env->startSection('title'); ?>
    Leave Application Add
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="add-leave-form" class="container mt-4">
    <h4>Add Leave Application</h4>
    <form action="" method="post" class="form-group">
        
        <div class="mb-3">
            <label for="leave-type" class="form-label">Leave Type</label>
            <select id="leave-type" name="leave_type" class="form-select" required>
                <option value="" selected disabled>Select Leave Type</option>
                <option value="Sick Leave">Sick Leave</option>
                <option value="Casual Leave">Casual Leave</option>
                <option value="Annual Leave">Annual Leave</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="start-date" class="form-label">Start Date</label>
            <input type="date" id="start-date" name="start_date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="end-date" class="form-label">End Date</label>
            <input type="date" id="end-date" name="end_date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="reason" class="form-label">Reason</label>
            <textarea id="reason" name="reason" class="form-control" rows="3" required></textarea>
        </div>
        <button type="submit" class="btn btn-success">Submit Leave Application</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/leave-app/add.blade.php ENDPATH**/ ?>