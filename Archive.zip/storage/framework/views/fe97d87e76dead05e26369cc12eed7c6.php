<?php $__env->startSection('title'); ?>
    Leave Application List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Leave Application List</h4>
        <a href="<?php echo e(route('leave-app.add')); ?>" class="btn btn-primary">+ Add Leave Application</a>
    </div>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Employee Name</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Example Rows -->
            <tr>
                <td>Rahul Verma</td>
                <td>Sick Leave</td>
                <td>2024-11-20</td>
                <td>2024-11-22</td>
                <td>Fever</td>
                <td>Approved</td>
                <td>
                    <button class="btn btn-info btn-sm">View</button>
                    <button class="btn btn-warning btn-sm">Edit</button>
                    <button class="btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>
            <tr>
                <td>Anil Kapoor</td>
                <td>Casual Leave</td>
                <td>2024-11-18</td>
                <td>2024-11-19</td>
                <td>Personal Work</td>
                <td>Pending</td>
                <td>
                    <button class="btn btn-info btn-sm">View</button>
                    <button class="btn btn-warning btn-sm">Edit</button>
                    <button class="btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projects/erp_four_f/erp_four_f/resources/views/pages/leave-app/list.blade.php ENDPATH**/ ?>