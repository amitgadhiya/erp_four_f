@extends('layouts.default')
@section('title')
    List Enquiry
@endsection
@section('content')
<div class="row">
    <div class="col-lg-12 d-flex justify-content-end">
        <a href="{{ route('enquiry.add') }}" class="btn btn-primary">Add Enquiry</a>
    </div>
</div>
<div class="table-responsive mt-3">
    <table id="enquiryTable" class="table table-bordered table-striped mt-3">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Enquiry No</th>
                <th>Client</th>
                <th>Date</th>
                <th>Priority</th>
                
                <th>Input </th>
                <th>Concept Working</th>
                <th>Concept Approval</th>
                <th>Remark </th>
                <th>Status </th>
                
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @php
                $clients = [
                    (object) [
                        'id' => 1,
                        'enquiry_no' => 'E-24-001',
                        'priority' => 'Cold',
                        'details' => 'Some thing related to the enquiry',
                        'client' => 'Client 1',
                        'input' => 'Complete',
                        'concept_working' => 'Complete',
                        'concept_approval' => 'Complete',
                        'date' => '2024-10-01',
                        'remark' => '',
                        'status' => 'Open',
                    ],
                    (object) [
                        'id' => 2,
                        'enquiry_no' => 'E-24-002',
                        'priority' => 'Warm',
                        'details' => 'what kind to product expected and details of it',
                        'client' => 'Client 2',
                        'input' => 'Complete',
                        'concept_working' => 'Complete',
                        'concept_approval' => 'Complete',
                        'date' => '2024-10-02',
                        'remark' => '',
                        'status' => 'Open',
                    ],
                    (object) [
                        'id' => 3,
                        'enquiry_no' => 'E-24-003',
                        'priority' => 'Hot',
                        'details' => 'can give it as big as required for exanple this one is too big,
                        
                        1) Pressure Gauges: Used to measure the pressure of gases or liquids in a system, ensuring safe and efficient operation.
                        
2) Temperature Gauges: Measure the temperature of a substance, often used in industrial applications to maintain optimal conditions.

3) Speed Gauges: Used to monitor the speed of machines, vehicles, or turbines, providing vital data for performance assessment.

4) Flow Gauges: Measure the flow rate of liquids or gases through pipes, helping maintain system efficiency and detect leaks.

5) Fuel Gauges: Indicate the remaining fuel in a vehicle or machine, ensuring timely refueling.',
                        'client' => 'Client 3',
                        'input' => 'Complete',
                        'concept_working' => 'Complete',
                        'concept_approval' => 'Complete',
                        'date' => '2024-10-03',
                        'remark' => '',
                        'status' => 'Open',
                    ],
                    (object) [
                        'id' => 4,
                        'enquiry_no' => 'E-24-004',
                        'priority' => 'Cold',
                        'details' => 'more info',
                        'client' => 'Client 4',
                        'input' => 'Complete',
                        'concept_working' => 'Complete',
                        'concept_approval' => 'Pending',
                        'date' => '2024-10-04',
                        'remark' => '',
                        'status' => 'Hold',
                    ],
                    (object) [
                        'id' => 5,
                        'enquiry_no' => 'E-24-005',
                        'priority' => 'Hot',
                        'details' => 'more info',
                        'client' => 'Client 5',
                        'input' => 'Pending',
                        'concept_working' => 'Pending',
                        'concept_approval' => 'Pending',
                        'date' => '2024-10-05',
                        'remark' => 'Pending for input',
                        'status' => 'Close',
                    ],
                    // Add more clients as needed
                ];
            @endphp
    
            @foreach ($clients as $client)
            <tr>
                <td>{{ $client->id }}</td>
                <td>{{ $client->enquiry_no }} 
                    <i class="fas fa-info-circle text-info" 
             data-bs-toggle="tooltip" 
             data-bs-trigger="click" 
             data-bs-placement="right" 
             title="{{ $client->details }}">
          </i>
                 </i>

                </td>
                <td>{{ $client->client }}</td>
                <td>{{ $client->date }}</td>
                <td class="{{ $client->priority == 'Hot' ? 'bg-danger' : ($client->priority == 'Warm' ? 'bg-warning' : ($client->priority == 'Cold' ? 'bg-primary' : '')) }}">{{ $client->priority }}</td>
                
                
                <td class="{{ $client->input == 'Complete' ? 'bg-success':''}}">{{ $client->input }}</td>
                <td class="{{ $client->concept_working == 'Complete' ? 'bg-success':''}}">{{ $client->concept_working }}</td>
                <td class="{{ $client->concept_approval == 'Complete' ? 'bg-success':''}}">{{ $client->concept_approval }}</td>
                <td>{{ $client->remark }}</td>
                <td>{{ $client->status }}</td>
                
                <td>
                    <div class="dropdown">
                        <button class="btn btn-link pr-3" type="button" id="dropdownMenuButton-{{ $client->id }}" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-{{ $client->id }}">
                            {{-- <li><a class="dropdown-item" href="{{ route('enquiry.view', $client->id) }}">View</a></li> --}}
                            
                            <li><a class="dropdown-item" href="{{ route('enquiry.edit', $client->id) }}">Edit</a></li>
                            <li><a class="dropdown-item" href="{{ route('quotation.add', $client->id) }}">convert to quotation</a></li>
                            <li><a class="dropdown-item" href="#">Reverse Enquiry</a></li>
                            {{-- <li><a class="dropdown-item" href="#">Save as</a></li> --}}
                        </ul>
                    </div>
                    
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    
</div>
<style>
    .btn-link {
        padding: 0;
        margin: 0;
    }
    .fa-ellipsis-v {
        font-size: 18px;
        cursor: pointer;
    }
</style>
@endsection
@section('script')
<script>
    $(document).ready(function() {
        $('#enquiryTable').DataTable({
            // You can customize the DataTable options here
            responsive: true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
<script>
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    });
  
    // Close all tooltips when a new one is clicked
    tooltipTriggerList.forEach(function (tooltipTriggerEl) {
      tooltipTriggerEl.addEventListener('click', function (event) {
        tooltipList.forEach(function (tooltip) {
          tooltip.hide(); // Hide all tooltips first
        });
        // Show the clicked tooltip
        var clickedTooltip = bootstrap.Tooltip.getInstance(event.currentTarget);
        clickedTooltip.show();
        event.stopPropagation();
      });
    });
  
    // Close tooltips when clicking outside
    document.addEventListener('click', function () {
      tooltipList.forEach(function (tooltip) {
        tooltip.hide();
      });
    });
  </script>
@endsection