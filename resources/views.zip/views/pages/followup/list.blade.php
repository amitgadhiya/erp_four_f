@extends('layouts.default')
@section('title')
    Follow-Up List
@endsection
@section('content')
<div class="row">
    <div class="col-lg-12 d-flex justify-content-end">
        <a href="{{ route('followup.add') }}" class="btn btn-primary">Add Follow-Up</a>
    </div>
</div>
<div class="table-responsive mt-3">
    <table id="quotationTable" class="table table-bordered table-striped mt-3">
        <thead class="table-dark">
            <tr>
                <th>Sr</th>
                <th>Follow Up Date</th>
                <th>Follow Up Details</th>
                <th>Next Follow Up Date</th>
                <th>Follow Up with</th>
                <th>Follow Up by</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @php
                $followups = [
                    (object) [
                        'id' => 1,
                        'date' => '15-10-24',
                        'details' => 'With in few days',
                        'next_date' => '01-11-24',
                        'with' => 'Rohit Sir',
                        'by' => 'User Name',
                        
                    ],
                    (object) [
                        'id' => 2,
                        'date' => '15-10-24',
                        'details' => 'More few days',
                        'next_date' => '01-11-24',
                        'with' => 'Rohit Sir',
                        'by' => 'User Name',
                    ],
                    (object) [
                        'id' => 3,
                        'date' => '1-11-24',
                        'details' => 'Sir not in town',
                        'next_date' => '10-11-24',
                        'with' => 'Rohit Sir',
                        'by' => 'User Name',
                    ],
                    (object) [
                        'id' => 4,
                        'date' => '10-11-24',
                        'details' => 'have talk and will be final in 2 days',
                        'next_date' => '15-11-24',
                        'with' => 'Rohit Sir',
                        'by' => 'User Name',
                    ],
                    (object) [
                        'id' => 5,
                        'date' => '15-11-24',
                        'details' => 'Have sent the PO',
                        'next_date' => '04-12-24',
                        'with' => 'Rohit Sir',
                        'by' => 'User Name',
                    ],
                    // Add more clients as needed
                ];
            @endphp
    
            @foreach ($followups as $followup)
            <tr>
                <td>{{ $followup->id }}</td>
                <td>{{ $followup->date }}</td>
                <td>{{ $followup->details }}</td>
                <td>{{ $followup->next_date }}</td>
                <td>{{ $followup->with }}</td>
                <td>{{ $followup->by }}</td>
                
                
                <td>
                    <a class="btn btn-success btn-sm" href="{{ route('followup.edit') }}">Edit</a>
                    <button class="btn btn-danger btn-sm">Delete</button>
                    
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection