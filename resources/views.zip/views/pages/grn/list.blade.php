@extends('layouts.default')
@section('title')
    GRN List
@endsection
@section('content')
<div class="row">
    <div class="col-lg-12">
        <table class="table">
            <thead>
                <tr>
                    <td>Sr</td>
                    <td>PO No</td>
                    <td>PO Date</td>
                    <td>Vender</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>PO-24-001</td>
                    <td>05-12-2024</td>
                    <td>Vender name</td>
                    <td>
                        <a href="{{route('grn.view')}}" class="btn btn-primary">Convert To GRN</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
@endsection
