@extends('layouts.default')
@section('title')
    GRN Convert
@endsection
@section('content')
<div class="row">
    <div class="col-lg-12">
        <form action="">
        <div class="row">
            <div class="col-lg-4">
                <table class="table">
                    <tr>
                        <td>PO No</td>
                        <td>PO-24-001</td>
                    </tr>
                    <tr>
                        <td>PO Date</td>
                        <td>05-12-2024</td>
                    </tr>
                    <tr>
                        <td>Vender</td>
                        <td>Vender Name</td>
                    </tr>
                    <tr>
                        <td>Invoice No</td>
                        <td><input type="text"></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table">
                    <thead>
                        <tr>
                            <td>Sr</td>
                            <td>Item</td>
                            <td>Qty</td>
                            <td>Rate</td>
                            <td>Dis</td>
                            <td>Gate In</td>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Item Name</td>
                            <td>10</td>
                            <td>100</td>
                            <td>10</td>
                            <td>5</td>
                            
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-lg-12">
                <input type="submit" class="btn btn-primary">
            </div>
        </div>
    </form>
    </div>
</div>

@endsection
