@extends('layouts.default')
@section('title')
    Issue Item
@endsection
@section('content')

<form action="">
<div class="row mt-3">
    
    <div class="col-lg-12">
        <table class="table">
            <thead>
                <tr>
                    <td>Sr</td>
                    <td>Item</td>
                    <td>In Stock</td>
                    <td>Issue</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Item name <br>Item desc and make and size</td>
                    <td>10</td>
                    <td><input type="text" class="form-control"></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Item name <br>Item desc and make and size</td>
                    <td>50</td>
                    <td><input type="text" class="form-control"></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Item name <br>Item desc and make and size</td>
                    <td>30</td>
                    <td><input type="text" class="form-control"></td>
                </tr>
            </tbody>
        </table>
    
    </div>
</div>
<div class="row mt-3">
    <div class="col-lg-4">
        <form action="#" >
            <!-- CSRF Token -->
            @csrf

            
            

            <div class="form-group">
                <label for="recipient">To Department Name</label>
                <select name="item" id="item" class="form-control">
                    <option value=""></option>
                    <option value="">Store</option>
                    <option value="">Work Shop</option>
                    <option value="">Quality</option>
                    <option value="">Assembly</option>
                </select>
            </div>

            <!-- Recipient Name -->
            <div class="form-group">
                <label for="recipient">Recipient Name</label>
                <select name="item" id="item" class="form-control">
                    <option value=""></option>
                    <option value="">User 1</option>
                    <option value="">User 2</option>
                    <option value="">User 3</option>
                    <option value="">User 4</option>
                </select>
            </div>

            <!-- Remarks -->
            <div class="form-group">
                <label for="remarks">Remarks</label>
                <textarea class="form-control" id="remarks" name="remarks" rows="3" placeholder="Enter remarks (optional)"></textarea>
            </div>
        </form>
    </div>
</div>
<div class="row mt-3">
    <div class="col-lg-12">
        <a href="#" class="btn btn-primary">Submit</a>
    </div>
</div>
</form>


@endsection
