@extends('layouts.default')
@section('title')
    Out-Ward Edit
@endsection
@section('content')
@endsection

