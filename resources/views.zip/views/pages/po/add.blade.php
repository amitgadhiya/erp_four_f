@extends('layouts.default')
@section('title')
    Add PO
@endsection
@section('content')
    <div class="row">

        <div class="col-lg-12">
            <form action="{{ route('po_item.list') }}" method="get">
                @csrf
                <div class="row">
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="project_no">PO No:</label>
                            <input type="text" class="form-control" id="project_no" name="project_no" value="PO-24-001" required>
                        </div>

                        

                        <div class="form-group">
                            <label for="project_end_date">PO Date:</label>
                            <input type="date" class="form-control" id="project_end_date" name="project_end_date"
                                required>
                        </div>

                        <div class="form-group">
                            <label for="project_name">PO type:</label>
                            <select name="project_no" class="form-control" id="project_no">
                                <option value="" selected disabled>select</option>
                                <option value="">Capex</option>
                                <option value="">Salable purchase for new Project</option>
                                <option value="">Salable purchase for inventory</option>
                                <option value="">Salable purchase for rejection</option>
                                <option value="">Salable service taken from supplier</option>
                                <option value="">Salable purchase for other.</option>
                                <option value="">Maintenance</option>
                                <option value="">Tooling</option>
                                <option value="">Consumable</option>
                                <option value="">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="client_name">Vender Name:</label>
                            <select name="vender" class="form-control" id="vender">
                                <option value="" selected disabled>select</option>
                                <option value="">Vender 1</option>
                                <option value="">Vender 2</option>
                                <option value="">Vender 3</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        {{-- <table class="table">
                            <thead>
                                <tr>
                                    <td>Sr.</td>
                                    <td>Item</td>
                                    <td>Qty</td>
                                    <td>Rate</td>
                                    <td>Discount</td>
                                    <td>Amount</td>
                                    <td>Select</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Item name has to be big fo this like whit will happen if it si very very big will it
                                        go to next line lets see</td>
                                    <td><input type="text" class="form-control" value="1"></td>
                                    <td><input type="text" class="form-control" value="50000"></td>
                                    <td><input type="text" class="form-control" value="10"></td>
                                    <td>45,000</td>
                                    <td><input type="radio" name="item" value="1"></td>

                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Item name has to be big fo this like whit will happen if it si very very big will it
                                        go to next line lets see</td>
                                    <td><input type="text" class="form-control" value="1"></td>
                                    <td><input type="text" class="form-control" value="100000"></td>
                                    <td><input type="text" class="form-control" value="0"></td>
                                    <td>100000</td>
                                    <td><input type="radio" name="item" value="2"></td>

                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Item name has to be big fo this like whit will happen if it si very very big will it
                                        go to next line lets see</td>
                                    <td><input type="text" class="form-control" value="2"></td>
                                    <td><input type="text" class="form-control" value="20000"></td>
                                    <td><input type="text" class="form-control" value="5"></td>
                                    <td>38,000</td>
                                    <td><input type="radio" name="item" value="3"></td>

                                </tr>
                            </tbody>
                        </table> --}}
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-lg-3">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('script')
@endsection
