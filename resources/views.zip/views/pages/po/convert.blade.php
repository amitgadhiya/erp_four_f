@extends('layouts.default')
@section('title')
    Make PO
@endsection
@section('content')
<div class="row">

    <div class="col-lg-12">
        <form action="{{ route('po.list') }}" method="get">
            @csrf
            <div class="row">
                <div class="col-lg-3">
                    <div class="form-group">
                        <label for="client_name">PO Number:</label>
                        <input type="text"  class="form-control" id="client_name" name="client_name" value="PO-RM-24-001" required>
                    </div>
                    <div class="form-group">
                        <label for="project_no">Project No:</label>
                        <input type="text" disabled class="form-control" id="project_no" name="project_no" value="P-24-001">
                    </div>

                    <div class="form-group">
                        <label for="client_name">Vender Name:</label>
                        <select name="vender" class="form-control" id="vender">
                            <option value="" selected disabled>select</option>
                            <option value="vender name 1">vender name 1</option>
                            <option value="vender name 2">vender name 2</option>
                            <option value="vender name 3">vender name 3</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="project_end_date">PO date:</label>
                        <input type="date" class="form-control" id="project_end_date" name="project_end_date"
                            required>
                    </div>

                    
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <table class="table table-bordered table-striped mt-3">
                        <thead  class="table-dark">
                            <tr>
                                <td>Sr.</td>
                                <td>Element Name</td>
                                <td>Material</td>
                                <td>Size</td>
                                <td>Required Qty</td>
                                <td>Last Rate</td>
                                <td>Type</td>
                                <td>Width</td>
                                <td>Base</td>
                                <td>Height</td>
                                <td>Weight</td>
                                <td>Qty</td>
                                <td>Rate</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>01_01</td>
                                <td>BASE-PLATE_1</td>
                                <td>C45</td>
                                <td>26X435X800</td>
                                <td>2</td>
                                <td>100</td>
                                <td><select name="" id="" class="form-control">
                                    <option value="" selected disabled>select</option>
                                    <option value="">Plate</option>
                                    <option value="">Round</option>
                                </select>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td></td>

                            </tr>
                            <tr>
                                <td>01_02</td>
                                <td>DIAL-GAUGE-BLOCK__1</td>
                                <td>MS</td>
                                <td>18X37X45</td>
                                <td>2</td>
                                <td>100</td>
                                <td><select  name="" id="" class="form-control">
                                    <option value="" selected disabled>select</option>
                                    <option value="">Plate</option>
                                    <option value="">Round</option>
                                </select>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td></td>

                            </tr>
                            <tr>
                                <td>01_03</td>
                                <td>MANIFOLD_BLOCK-FFE01_1</td>
                                <td>MS-BRIGHT</td>
                                <td>32X50X90</td>
                                <td>2</td>
                                <td>100</td>
                                <td><select name="" id=""  class="form-control">
                                    <option value="" disabled selected>select</option>
                                    <option value="">Plate</option>
                                    <option value="">Round</option>
                                </select>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td><input type="text" class="form-control" value=""></td>
                                <td></td>

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-lg-3">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection

@section('script')
@endsection
