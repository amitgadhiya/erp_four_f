@extends('layouts.default')
@section('title')
    PO Item Add
@endsection
@section('content')
    <div class="row">
        <div class="col-lg-12">
            <form action="{{ route('po_item.add.post')}}" method="POST">
                <div class="row">
                    <div class="col-lg-4">

                        <!-- CSRF Token (if needed in Laravel) -->
                        @csrf

                        

                        <!-- Item Name -->
                        <div class="form-group">
                            <label for="itemName">Item Name</label>
                            <select name="item" id="item" class="form-control" >
                                <option value="">Item 1</option>
                                <option value="">Item 2</option>
                                <option value="">Item 3</option>
                            </select>
                        </div>
                        
                        <!-- Quantity -->
                        <div class="form-group">
                            <label for="quantity">Qty</label>
                            <input type="number" class="form-control" id="quantity" name="quantity"
                                placeholder="Enter quantity" required>
                        </div>

                        <!-- Rate -->
                        <div class="form-group">
                            <label for="rate">Rate</label>
                            <input type="number" step="0.01" class="form-control" id="rate" name="rate"
                                placeholder="Enter rate" required>
                        </div>

                        <!-- Discount -->
                        <div class="form-group">
                            <label for="discount">Dis (Discount)</label>
                            <input type="number" step="0.01" class="form-control" id="discount" name="discount"
                                placeholder="Enter discount" required>
                        </div>

                        

                        <!-- Amount -->
                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="number" readonly step="0.01" class="form-control" id="amount" name="amount"
                                placeholder="Enter amount" >
                        </div>

                        

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-primary">Add Item</button>

                    </div>

                </div>
            </form>

        </div>
    </div>
@endsection

@section('script')
@endsection
