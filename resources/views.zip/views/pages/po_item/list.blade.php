@extends('layouts.default')
@section('title')
     PO List
@endsection
@section('content')


<div class="row">
    <div class="col-lg-4 text-right">
        <table class="table">
            <tr>
                <td>Project No</td>
                <td>P-24-003</td>
            </tr>
            <tr>
                <td>Customer Name</td>
                <td>ABC comapany</td>
            </tr>
        </table>
    </div>
</div>
<div class="row mt-3 mr-3">
    <div class="col-lg-12">
        <form action="{{ route('po_item.add.post')}}" method="POST" class="d-flex flex-wrap align-items-center gap-3">
            <!-- CSRF Token (if needed in Laravel) -->
            @csrf

            <!-- Item Name -->
            <div class="form-group">
                <label for="itemName">Item Name</label>
                <select name="item" id="item" class="form-control">
                    <option value="">Item 1</option>
                    <option value="">Item 2</option>
                    <option value="">Item 3</option>
                </select>
            </div>

            <!-- Quantity -->
            <div class="form-group">
                <label for="quantity">Qty</label>
                <input type="number" class="form-control" id="quantity" name="quantity"
                    placeholder="Enter quantity" required>
            </div>

            <!-- Rate -->
            <div class="form-group">
                <label for="rate">Rate</label>
                <input type="number" step="0.01" class="form-control" id="rate" name="rate"
                    placeholder="Enter rate" required>
            </div>

            <!-- Discount -->
            <div class="form-group">
                <label for="discount">Dis (Discount)</label>
                <input type="number" step="0.01" class="form-control" id="discount" name="discount"
                    placeholder="Enter discount" required>
            </div>

            <!-- Amount -->
            <div class="form-group">
                <label for="amount">Amount</label>
                <input type="number" readonly step="0.01" class="form-control" id="amount" name="amount"
                    placeholder="Enter amount">
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary">Add Item</button>
        </form>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="table-responsive mt-3">
            <table id="itemTable" class="display">
                <thead>
                    <tr>
                        <th>Sr.</th>
                        <th>Item Name</th>
                        <th>Qty</th>
                        <th>Rate</th>
                        <th>Dis</th>
                        <th>Tax</th>
                        <th>Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $items = [
                            (object) [
                                'id' => 1,
                                'po_item' => 'Item name 1',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            (object) [
                                'id' => 2,
                                'po_item' => 'Item name 2',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            (object) [
                                'id' => 3,
                                'po_item' => 'Item name 3',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            (object) [
                                'id' => 4,
                                'po_item' => 'Item name 4',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            (object) [
                                'id' => 5,
                                'po_item' => 'Item name 5',
                                'qty' => '1 nos',
                                'rate' => '5000',
                                'discount' => '10',
                                'tax' => '18',
                                'amount' => '3000',
                                'status' => 'Ordered',
                            ],
                            // Add more clients as needed
                        ];
                    @endphp
            
                    @foreach ($items as $item)
                    <tr>
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->po_item }}</td>
                        <td>{{ $item->qty }}</td>
                        <td>{{ $item->rate }}</td>
                        
                        <td>{{ $item->discount }}</td>
                        <td>{{ $item->tax }}</td>
                        <td>{{ $item->amount }}</td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-link pr-3" type="button" id="dropdownMenuButton-{{ $item->id }}" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-{{ $item->id }}">
                                    
                                    
                                    <li><a class="dropdown-item" href="{{ route('po_item.edit', $item->id) }}">Edit </a></li>

                                    <li><a class="dropdown-item" href="{{ route('po_item.delete', $item->id) }}">Delete</a></li>
                                    
                                </ul>
                            </div>
                            
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
    $(document).ready(function() {
        $('#itemTable').DataTable({
            // You can customize the DataTable options here
            responsive: true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
@endsection
