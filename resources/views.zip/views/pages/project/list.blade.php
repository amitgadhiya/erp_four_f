@extends('layouts.default')
@section('title')
    Project List 
@endsection
@section('content')
<div class="row">
    <div class="col-lg-12">

    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="table-responsive mt-3">
            <table id="projectTable" class="table table-bordered table-striped mt-3">
                <thead class="table-dark">
                    <tr>
                        <th>Sr.</th>
                        <th>Project no</th>
                        <th>Client</th>
                        <th>Date</th>
                        
                        <th>Cust PO<br> Status</th>
                        <th>Prority</th>
                        <th>Input<br>Status</th>
                        <th>DAP Status</th>
                        <th>DAP  
                            Approval<br> Status</th>
                        <th>Final</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $projects = [
                            (object) [
                                'id' => 1,
                                'project_no' => 'PJ001',
                                'client' => 'Client 1',
                                'date' => '2024-10-01',
                                'designer' => 'User 1',
                                'input_status' => 'Pending',
                                'dap_status' => 'Load',
                                'dap_app_status' => 'Pending',
                                'final' => 'Load',
                                'status' => 'Pending',
                                'prority' => 'Hot',
                            ],
                            (object) [
                                'id' => 2,
                                'project_no' => 'PJ002',
                                'client' => 'Client 2',
                                'date' => '2024-10-02',
                                'designer' => 'User 1',
                                'input_status' => 'Pending',
                                'dap_status' => 'Load',
                                'dap_app_status' => 'Pending',
                                'final' => 'Load',
                                'status' => 'Pending',
                                'prority' => 'Hot',
                            ],
                            (object) [
                                'id' => 3,
                                'project_no' => 'PJ003',
                                'client' => 'Client 3',
                                'date' => '2024-10-03',
                                'designer' => 'User 1',
                                'input_status' => 'Pending',
                                'dap_status' => 'Load',
                                'dap_app_status' => 'Pending',
                                'final' => 'Load',
                                'status' => 'Pending',
                                'prority' => 'Hot',
                            ],
                            (object) [
                                'id' => 4,
                                'project_no' => 'PJ004',
                                'client' => 'Client 4',
                                'date' => '2024-10-04',
                                'designer' => 'User 1',
                                'input_status' => 'Pending',
                                'dap_status' => 'Load',
                                'dap_app_status' => 'Pending',
                                'final' => 'Complete',
                                'status' => 'Pending',
                                'prority' => 'Hot',
                            ],
                            (object) [
                                'id' => 5,
                                'project_no' => 'PJ005',
                                'client' => 'Client 5',
                                'date' => '2024-10-05',
                                'designer' => 'User 1',
                                'input_status' => 'Complete',
                                'dap_status' => 'Load',
                                'dap_app_status' => 'Pending',
                                'final' => 'Inprocess',
                                'status' => 'Pending',
                                'prority' => 'Hot',
                            ],
                            // Add more clients as needed
                        ];
                    @endphp
            
                    @foreach ($projects as $project)
                    <tr>
                        <td>{{ $project->id }}</td>
                        <td>{{ $project->project_no }}</td>
                        <td>{{ $project->client }}</td>
                        <td>{{ $project->date }}</td>
                        
                        <td>{{ $project->status }}</td>
                        <td>{{ $project->prority }}</td>
                        
                        <td class="{{ $project->input_status == 'Pending' ? "bg-warning":"" }}">{{ $project->input_status }}</td>

                        <td class="{{ $project->dap_status == 'Load' ? "bg-danger": ($project->dap_status == 'Inprocess' ? "bg-warning" : "bg-success")}}">{{ $project->dap_status }}</td>

                        <td class="{{ $project->dap_app_status == 'Pending' ? "bg-warning":"" }}">{{ $project->dap_app_status }}</td>

                        <td class="{{ $project->final == 'Load' ? "bg-danger": ($project->final == 'Inprocess' ? "bg-warning" : "bg-success")}}">{{ $project->final }}</td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-link pr-3" type="button" id="dropdownMenuButton-{{ $project->id }}" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-{{ $project->id }}">
                                    <li><a class="dropdown-item" href="{{ route('element_in_project.list', $project->id) }}">Manage Elements</a></li>
                                    
                                    <li><a class="dropdown-item" href="{{ route('project.edit', $project->id) }}">Edit Project</a></li>

                                    <li><a class="dropdown-item" href="{{ route('po.convert', $project->id) }}">Make PO of it</a></li>
                                    
                                </ul>
                            </div>
                            
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            
        </div>
    </div>
</div>

@endsection

@section('script')

<script>
    $(document).ready(function() {
        $('#projectTable').DataTable({
            // You can customize the DataTable options here
            responsive: true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
@endsection